"""Initial PostgreSQL Schema Migration for Inference and Drift Logs

Revision ID: 001_initial_schema
Revises: 
Create Date: 2026-09-02 00:00:00.000000

"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = '001_initial_schema'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # 1. Create inference_logs table
    op.create_table(
        'inference_logs',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True, autoincrement=True),
        sa.Column('timestamp', sa.DateTime(), nullable=True, index=True),
        sa.Column('car_name', sa.String(length=100), nullable=True),
        sa.Column('features_json', sa.Text(), nullable=False),
        sa.Column('predicted_price', sa.Float(), nullable=False),
        sa.Column('latency_ms', sa.Float(), nullable=True),
        sa.Column('model_version', sa.String(length=50), nullable=True),
        sa.Column('actual_price', sa.Float(), nullable=True),
        sa.Column('absolute_error', sa.Float(), nullable=True),
        sa.Column('error_percentage', sa.Float(), nullable=True),
    )

    # 2. Create drift_logs table
    op.create_table(
        'drift_logs',
        sa.Column('id', sa.Integer(), nullable=False, primary_key=True, autoincrement=True),
        sa.Column('timestamp', sa.DateTime(), nullable=True, index=True),
        sa.Column('drift_status', sa.String(length=50), nullable=False),
        sa.Column('ks_test_drifted_features', sa.Text(), nullable=True),
        sa.Column('psi_drifted_features', sa.Text(), nullable=True),
        sa.Column('sample_size', sa.Integer(), nullable=True),
        sa.Column('retrain_triggered', sa.Boolean(), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
    )


def downgrade() -> None:
    op.drop_table('drift_logs')
    op.drop_table('inference_logs')
