"""
PostgreSQL Database Provisioning & Schema Initialization Script.
Tests connection to a target PostgreSQL database, creates tables, and verifies read/write capabilities.
Usage:
    python scripts/init_postgres.py --url postgresql://user:password@localhost:5432/car_price_db
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import os
import argparse
import logging
from sqlalchemy import create_engine, text
from app.db import Base, InferenceLog, DriftLog

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("PostgresInitializer")


def setup_postgresql(database_url: str):
    logger.info("=" * 70)
    logger.info("       POSTGRESQL DATABASE SCHEMA INITIALIZER")
    logger.info("=" * 70)
    
    if database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql://", 1)

    logger.info(f"Target Database: {database_url.split('@')[-1] if '@' in database_url else database_url}")

    try:
        engine = create_engine(database_url, pool_pre_ping=True)
        
        # Test connection
        with engine.connect() as conn:
            result = conn.execute(text("SELECT version();")).fetchone()
            logger.info(f"Connected to PostgreSQL: {result[0]}")

        # Create all tables
        logger.info("Creating tables: 'inference_logs', 'drift_logs'...")
        Base.metadata.create_all(bind=engine)
        logger.info("All PostgreSQL tables successfully initialized!")
        
        return True
    except Exception as e:
        logger.error(f"PostgreSQL connection/setup failed: {e}")
        return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Initialize PostgreSQL Database Schema")
    parser.add_argument(
        "--url",
        type=str,
        default=os.getenv("DATABASE_URL", "postgresql://mlops_user:mlops_password@localhost:5432/car_price_db"),
        help="PostgreSQL Connection URL"
    )
    args = parser.parse_args()
    setup_postgresql(args.url)
