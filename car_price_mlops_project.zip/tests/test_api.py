"""
API Integration Tests for FastAPI Endpoints.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from fastapi.testclient import TestClient
from app.main import app


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def test_root_endpoint(client):
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "message" in data
    assert data["docs_url"] == "/docs"


def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert "status" in data
    assert "service" in data


def test_validation_report_endpoint(client):
    response = client.get("/validation_report")
    assert response.status_code == 200
    data = response.json()
    assert "validation_status" in data
    assert data["validation_status"] == "PASSED"
    assert data["checks_summary"]["passed_checks"] >= 5


def test_predict_single_endpoint(client):
    sample_car = {
        "CarName": "honda accord lx",
        "symboling": 0,
        "fueltype": "gas",
        "aspiration": "std",
        "doornumber": "four",
        "carbody": "sedan",
        "drivewheel": "fwd",
        "enginelocation": "front",
        "wheelbase": 96.5,
        "carlength": 163.4,
        "carwidth": 64.0,
        "carheight": 54.5,
        "curbweight": 2010.0,
        "enginetype": "ohc",
        "cylindernumber": "four",
        "enginesize": 92.0,
        "fuelsystem": "1bbl",
        "boreratio": 2.91,
        "stroke": 3.41,
        "compressionratio": 9.2,
        "horsepower": 76.0,
        "peakrpm": 6000.0,
        "citympg": 30.0,
        "highwaympg": 34.0
    }
    
    response = client.post("/predict", json=sample_car)
    # If model is trained, it should return 200
    if response.status_code == 200:
        data = response.json()
        assert "predicted_price" in data
        assert data["predicted_price"] > 0
        assert "predicted_price_formatted" in data
        assert data["status"] == "success"
    else:
        # If model not trained yet, should be 503
        assert response.status_code in [200, 503]


def test_batch_predict_endpoint(client):
    batch_payload = {
        "cars": [
            {
                "CarName": "toyota corolla",
                "symboling": 0,
                "curbweight": 2200.0,
                "horsepower": 80.0,
                "enginesize": 100.0
            },
            {
                "CarName": "bmw m3",
                "symboling": 2,
                "curbweight": 3500.0,
                "horsepower": 250.0,
                "enginesize": 200.0
            }
        ]
    }
    
    response = client.post("/batch_predict", json=batch_payload)
    if response.status_code == 200:
        data = response.json()
        assert data["total_count"] == 2
        assert len(data["predictions"]) == 2
        assert data["predictions"][0]["predicted_price"] > 0
        assert data["predictions"][1]["predicted_price"] > 0
    else:
        assert response.status_code in [200, 503]
