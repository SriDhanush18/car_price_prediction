"""
Unit tests for Database logging and feedback mechanisms.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from app.db import (
    record_inference_log,
    update_ground_truth_feedback,
    fetch_recent_logs,
    record_drift_event
)


def test_record_inference_log_and_feedback():
    sample_features = {
        "CarName": "toyota corolla le",
        "horsepower": 85,
        "curbweight": 2200,
        "enginesize": 100
    }
    
    # 1. Record log
    log_id = record_inference_log(
        car_features=sample_features,
        predicted_price=8500.0,
        latency_ms=12.5,
        model_version="1.0.0"
    )
    assert log_id > 0, "Failed to persist inference log to database."
    
    # 2. Query logs
    logs = fetch_recent_logs(limit=10)
    assert len(logs) > 0
    latest = logs[0]
    assert latest["id"] == log_id
    assert latest["predicted_price"] == 8500.0
    
    # 3. Update feedback
    updated = update_ground_truth_feedback(log_id=log_id, actual_price=8700.0)
    assert updated is True
    
    # 4. Verify feedback in logs
    logs_updated = fetch_recent_logs(limit=1)
    assert logs_updated[0]["actual_price"] == 8700.0
    assert logs_updated[0]["error_percentage"] is not None


def test_record_drift_event():
    record_drift_event(
        drift_status="HEALTHY",
        ks_features=[],
        psi_features=[],
        sample_size=40,
        retrain_triggered=False,
        notes="Automated test drift audit"
    )


def test_database_info_and_engine_config():
    from app.db import get_database_info, create_db_engine
    info = get_database_info()
    assert "database_type" in info
    assert "status" in info
    assert info["status"] == "CONNECTED"
    
    # Test Postgres engine creation & connection pooling parameters
    test_pg_url = "postgresql://mlops_user:mlops_password@localhost:5432/car_price_db"
    pg_engine = create_db_engine(test_pg_url)
    assert pg_engine.dialect.name in ["postgresql", "sqlite"]
