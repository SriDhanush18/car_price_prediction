"""
Test Suite for MLOps Car Price Prediction.
"""
