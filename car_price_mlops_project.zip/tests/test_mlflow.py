"""
Unit tests for MLflow Experiment Tracking, Metric Logging, and Model Registry.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
import mlflow
from src.mlflow_utils import (
    setup_mlflow,
    log_experiment_run,
    get_latest_registered_model,
    list_mlflow_runs,
    EXPERIMENT_NAME,
    REGISTERED_MODEL_NAME
)
from src.config import MODEL_SAVE_PATH
import joblib


def test_mlflow_setup():
    uri = setup_mlflow()
    assert "sqlite" in uri or "mlflow.db" in uri or "mlruns" in uri
    assert mlflow.get_experiment_by_name(EXPERIMENT_NAME) is not None


def test_mlflow_log_experiment_run():
    sample_metrics = {
        "test_r2": 0.9538,
        "test_mae": 1299.99,
        "test_rmse": 1909.82,
        "test_mape_pct": 9.67
    }
    sample_params = {
        "algorithm": "RandomForestRegressor",
        "n_estimators": 150,
        "max_depth": "None",
        "cv_folds": 5
    }
    
    run_id = log_experiment_run(
        run_name="Pytest_Unit_Test_Run",
        pipeline_obj=None,
        params=sample_params,
        metrics=sample_metrics,
        tags={"environment": "pytest", "test_type": "unit"}
    )
    
    assert run_id is not None
    assert len(run_id) > 10


def test_list_mlflow_runs():
    runs = list_mlflow_runs(limit=10)
    assert isinstance(runs, list)
    assert len(runs) > 0
    assert "run_id" in runs[0]
    assert "run_name" in runs[0]
    assert "status" in runs[0]


def test_model_registry_query():
    # If a model has been registered, verify its structure
    reg_info = get_latest_registered_model(REGISTERED_MODEL_NAME)
    if reg_info:
        assert reg_info["name"] == REGISTERED_MODEL_NAME
        assert "version" in reg_info
        assert "current_stage" in reg_info
