"""
Unit tests for Multi-Agent AI system and specialized agents.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from src.agents.orchestrator import (
    DataQualityAgent,
    ModelGovernanceAgent,
    DriftOpsAgent,
    PricingIntelligenceAgent,
    MLOpsMultiAgentOrchestrator
)


def test_data_quality_agent():
    agent = DataQualityAgent()
    # Test typo detection
    res = agent.analyze({"CarName": "vokswagen rabbit", "horsepower": 100, "curbweight": 2000, "enginesize": 90})
    assert res["status"] in ["PASSED", "WARNING"]
    assert any("volkswagen" in iss for iss in res["issues_detected"])


def test_model_governance_agent():
    agent = ModelGovernanceAgent()
    res = agent.audit_production_model()
    assert res["test_r2_score"] > 0.85
    assert "compliance_status" in res


def test_drift_ops_agent():
    agent = DriftOpsAgent()
    res = agent.evaluate_drift()
    assert "drift_status" in res
    assert "retraining_decision" in res


def test_pricing_intelligence_agent():
    agent = PricingIntelligenceAgent()
    res = agent.explain_valuation(
        car_features={"CarName": "porsche 911 turbo", "horsepower": 240, "curbweight": 3100, "enginesize": 220},
        predicted_price=34000.0
    )
    assert "market_segment" in res
    assert "Luxury" in res["market_segment"] or "High-Performance" in res["market_segment"]


def test_multi_agent_orchestrator():
    orchestrator = MLOpsMultiAgentOrchestrator()
    analysis = orchestrator.process_vehicle_valuation(
        car_features={"CarName": "toyota corolla", "horsepower": 80, "curbweight": 2200, "enginesize": 100},
        predicted_price=8100.0
    )
    assert analysis["orchestrator_status"] == "SUCCESS"
    assert "data_quality_agent" in analysis
    assert "pricing_intelligence_agent" in analysis
    assert "model_governance_agent" in analysis
    assert "drift_ops_agent" in analysis
