"""
Unit tests for Data Version Control (DVC) integrity and pointer tracking.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
import yaml
from src.dvc_manager import compute_file_md5, get_all_tracked_datasets
from src.config import BASE_DIR, RAW_DATA_PATH


def test_dvc_config_and_pointer_files():
    dvc_config = BASE_DIR / ".dvc" / "config"
    assert dvc_config.exists(), "DVC repository configuration (.dvc/config) is missing."
    
    raw_dvc = BASE_DIR / "data" / "raw" / "CarPrice_Assignment.csv.dvc"
    assert raw_dvc.exists(), "Raw dataset DVC pointer file missing."
    
    with open(raw_dvc, "r") as f:
        data = yaml.safe_load(f)
        assert "outs" in data
        assert data["outs"][0]["path"] == "CarPrice_Assignment.csv"
        assert len(data["outs"][0]["md5"]) == 32


def test_dvc_dataset_md5_checksums():
    md5_hash = compute_file_md5(RAW_DATA_PATH)
    assert md5_hash == "281776677a13ba267219267d360669b6", "Raw dataset checksum altered."


def test_get_all_tracked_datasets():
    datasets = get_all_tracked_datasets()
    assert len(datasets) >= 3
    dataset_names = [d["dataset_name"] for d in datasets]
    assert "CarPrice_Assignment.csv" in dataset_names
    assert "train.csv" in dataset_names
    assert "test.csv" in dataset_names
