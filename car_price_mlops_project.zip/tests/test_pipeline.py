"""
Unit Tests for Data Ingestion, Preprocessing, and Prediction Pipeline.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
import numpy as np
import pandas as pd

from src.data_loader import load_raw_data, split_and_save_data
from src.ingestion import DataIngestion, ingest_and_validate_data
from src.preprocessor import CarFeatureEngineer, build_preprocessor_pipeline
from src.evaluate import calculate_metrics
from src.predict import CarPricePredictor
from src.config import RAW_DATA_PATH, MODEL_SAVE_PATH


def test_data_ingestion_and_validation():
    ingestion = DataIngestion(RAW_DATA_PATH)
    df = ingestion.ingest_raw_data()
    assert isinstance(df, pd.DataFrame), "Ingested data is not a pandas DataFrame"
    assert len(df) == 205, f"Expected 205 rows, got {len(df)}"
    
    is_valid, report = ingestion.validate_data(df)
    assert is_valid is True, f"Validation failed: {report}"
    assert report["validation_status"] == "PASSED"
    assert report["checks_summary"]["failed_checks"] == 0
    assert report["detailed_checks"]["missing_values_check"]["passed"] is True
    assert report["detailed_checks"]["schema_columns_check"]["passed"] is True


def test_data_loading():
    df = load_raw_data(RAW_DATA_PATH)
    assert not df.empty, "Loaded dataframe is empty"
    assert "price" in df.columns, "Target column 'price' not in DataFrame"
    assert "CarName" in df.columns, "'CarName' column missing"
    assert len(df) >= 200, f"Expected at least 200 rows, got {len(df)}"


def test_train_test_split():
    df = load_raw_data(RAW_DATA_PATH)
    train_df, test_df = split_and_save_data(df)
    assert len(train_df) + len(test_df) == len(df)
    assert abs(len(test_df) / len(df) - 0.20) < 0.05


def test_feature_engineering_transformer():
    sample_df = pd.DataFrame([{
        "CarName": "vokswagen rabbit",
        "doornumber": "two",
        "cylindernumber": "four",
        "curbweight": 2000,
        "horsepower": 100,
        "carlength": 160,
        "carwidth": 60,
        "carheight": 50,
        "citympg": 30,
        "highwaympg": 40,
        "enginesize": 100,
        "symboling": 1
    }])
    
    transformer = CarFeatureEngineer()
    transformed_df = transformer.fit_transform(sample_df)
    
    # Check brand typo correction
    assert transformed_df["brand"].iloc[0] == "volkswagen"
    # Check door and cylinder integer conversions
    assert transformed_df["doornumber_num"].iloc[0] == 2.0
    assert transformed_df["cylindernumber_num"].iloc[0] == 4.0
    # Check domain features
    assert transformed_df["power_to_weight"].iloc[0] == 100 / 2000
    assert transformed_df["car_volume"].iloc[0] == 160 * 60 * 50
    assert transformed_df["avg_mpg"].iloc[0] == 30 * 0.55 + 40 * 0.45
    assert transformed_df["is_luxury_brand"].iloc[0] == 0.0


def test_preprocessor_pipeline_output():
    df = load_raw_data(RAW_DATA_PATH)
    X = df.drop(columns=["price"])
    pipeline = build_preprocessor_pipeline()
    X_trans = pipeline.fit_transform(X)
    
    assert isinstance(X_trans, np.ndarray), "Pipeline output is not a numpy array"
    assert X_trans.shape[0] == len(df), "Row count mismatch after transformation"
    assert not np.isnan(X_trans).any(), "Transformed data contains NaN values"


def test_metrics_calculation():
    y_true = np.array([10000, 20000, 30000])
    y_pred = np.array([11000, 19000, 31000])
    metrics = calculate_metrics(y_true, y_pred, n_features=2)
    
    assert "r2_score" in metrics
    assert "mae" in metrics
    assert "rmse" in metrics
    assert metrics["mae"] == 1000.0
    assert metrics["rmse"] == 1000.0
