"""
Unit tests for Statistical Drift Detection and PSI calculation.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
import pandas as pd
import numpy as np
from src.drift_detector import DataDriftDetector, calculate_psi


def test_calculate_psi_no_drift():
    s1 = pd.Series(["gas", "gas", "gas", "diesel", "gas"] * 20)
    s2 = pd.Series(["gas", "gas", "gas", "diesel", "gas"] * 20)
    psi = calculate_psi(s1, s2)
    assert psi < 0.05, f"Expected near zero PSI for identical distributions, got {psi}"


def test_calculate_psi_high_drift():
    s1 = pd.Series(["gas"] * 100)
    s2 = pd.Series(["diesel"] * 100)
    psi = calculate_psi(s1, s2)
    assert psi > 0.5, f"Expected high PSI for disjoint distributions, got {psi}"


def test_data_drift_detector_execution():
    detector = DataDriftDetector()
    report = detector.run_drift_analysis()
    
    assert "overall_drift_status" in report
    assert "numerical_ks_drift" in report
    assert "categorical_psi_drift" in report
    assert "baseline_sample_size" in report
    assert report["baseline_sample_size"] == 205
