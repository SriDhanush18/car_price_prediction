"""
Pydantic Data Validation Schemas for FastAPI Endpoints.
"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class CarFeatures(BaseModel):
    CarName: Optional[str] = Field(default="toyota corolla", description="Car make and model name", examples=["toyota corolla"])
    symboling: Optional[int] = Field(default=0, description="Insurance risk rating (-3 to +3)", examples=[0])
    fueltype: Optional[str] = Field(default="gas", description="Fuel type: gas or diesel", examples=["gas"])
    aspiration: Optional[str] = Field(default="std", description="Aspiration: std or turbo", examples=["std"])
    doornumber: Optional[str] = Field(default="four", description="Number of doors: two or four", examples=["four"])
    carbody: Optional[str] = Field(default="sedan", description="Body style: sedan, hatchback, wagon, hardtop, convertible", examples=["sedan"])
    drivewheel: Optional[str] = Field(default="fwd", description="Drive wheel: fwd, rwd, 4wd", examples=["fwd"])
    enginelocation: Optional[str] = Field(default="front", description="Engine location: front or rear", examples=["front"])
    wheelbase: Optional[float] = Field(default=98.8, description="Wheelbase in inches", examples=[98.8])
    carlength: Optional[float] = Field(default=177.8, description="Car length in inches", examples=[177.8])
    carwidth: Optional[float] = Field(default=66.5, description="Car width in inches", examples=[66.5])
    carheight: Optional[float] = Field(default=55.5, description="Car height in inches", examples=[55.5])
    curbweight: Optional[float] = Field(default=2410.0, description="Curb weight in lbs", examples=[2410.0])
    enginetype: Optional[str] = Field(default="ohc", description="Engine type: ohc, dohc, ohcv, l, rotor, ohcf, dohcv", examples=["ohc"])
    cylindernumber: Optional[str] = Field(default="four", description="Number of cylinders: two, three, four, five, six, eight, twelve", examples=["four"])
    enginesize: Optional[float] = Field(default=122.0, description="Engine displacement size", examples=[122.0])
    fuelsystem: Optional[str] = Field(default="mpfi", description="Fuel injection system: mpfi, 2bbl, 1bbl, idi, spdi, 4bbl, spfi, mfi", examples=["mpfi"])
    boreratio: Optional[float] = Field(default=3.39, description="Bore ratio", examples=[3.39])
    stroke: Optional[float] = Field(default=3.39, description="Stroke", examples=[3.39])
    compressionratio: Optional[float] = Field(default=8.6, description="Compression ratio", examples=[8.6])
    horsepower: Optional[float] = Field(default=84.0, description="Horsepower", examples=[84.0])
    peakrpm: Optional[float] = Field(default=4800.0, description="Peak RPM", examples=[4800.0])
    citympg: Optional[float] = Field(default=26.0, description="City MPG", examples=[26.0])
    highwaympg: Optional[float] = Field(default=32.0, description="Highway MPG", examples=[32.0])


class PredictionResponse(BaseModel):
    car_identifier: str
    predicted_price: float
    predicted_price_formatted: str
    status: str = "success"


class BatchCarFeatures(BaseModel):
    cars: List[CarFeatures]


class BatchPredictionResponse(BaseModel):
    total_count: int
    predictions: List[PredictionResponse]
    status: str = "success"


class ModelInfoResponse(BaseModel):
    project_name: str
    version: str
    model_name: str
    target_metric: str
    r2_score: float
    mae: float
    rmse: float
    status: str


class FeedbackRequest(BaseModel):
    log_id: int = Field(description="ID of the inference log entry", examples=[1])
    actual_price: float = Field(description="Real-world actual selling price", examples=[9500.0])


class DriftResponse(BaseModel):
    timestamp: str
    overall_drift_status: str
    drifted_features_count: int
    retraining_recommended: bool
    numerical_ks_drift: Dict[str, Any]
    categorical_psi_drift: Dict[str, Any]


class MultiAgentValuationRequest(BaseModel):
    car: CarFeatures


class MultiAgentValuationResponse(BaseModel):
    orchestrator_status: str
    vehicle_valuation: str
    consensus_verdict: str
    data_quality_agent: Dict[str, Any]
    pricing_intelligence_agent: Dict[str, Any]
    model_governance_agent: Dict[str, Any]
    drift_ops_agent: Dict[str, Any]
