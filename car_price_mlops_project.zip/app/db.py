"""
Database Layer for Production Inference Logging and Feedback Storage.
Uses SQLAlchemy with SQLite (default) or PostgreSQL.
Stores real-time inference payloads for downstream monitoring, drift detection, and automated retraining.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    Float,
    String,
    Text,
    DateTime,
    Boolean,
    desc
)
from sqlalchemy.orm import declarative_base, sessionmaker, Session

from src.config import BASE_DIR, DATA_DIR

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("DatabaseManager")

DB_PATH = DATA_DIR / "production_inference.db"
DEFAULT_DB_URL = f"sqlite:///{str(DB_PATH).replace(os.sep, '/')}"
RAW_DATABASE_URL = os.getenv("DATABASE_URL", DEFAULT_DB_URL)

# Normalize legacy postgres:// URI to standard postgresql://
if RAW_DATABASE_URL.startswith("postgres://"):
    RAW_DATABASE_URL = RAW_DATABASE_URL.replace("postgres://", "postgresql://", 1)

DATABASE_URL = RAW_DATABASE_URL


def create_db_engine(url: str):
    """Create SQLAlchemy engine with appropriate connection pooling for PostgreSQL/SQLite."""
    try:
        if "postgresql" in url:
            return create_engine(
                url,
                pool_size=10,
                max_overflow=20,
                pool_pre_ping=True,
                pool_recycle=300
            )
        else:
            return create_engine(
                url,
                connect_args={"check_same_thread": False}
            )
    except Exception as e:
        logger.warning(f"Could not connect to configured DB ({url}). Falling back to local SQLite: {e}")
        return create_engine(DEFAULT_DB_URL, connect_args={"check_same_thread": False})


engine = create_db_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_database_info() -> Dict[str, Any]:
    """Retrieve runtime database configuration and active dialect."""
    dialect_name = engine.dialect.name
    return {
        "database_type": "PostgreSQL" if dialect_name == "postgresql" else "SQLite (Embedded)",
        "dialect": dialect_name,
        "database_url_masked": str(engine.url).split("@")[-1] if "@" in str(engine.url) else str(engine.url),
        "status": "CONNECTED"
    }


class InferenceLog(Base):
    """Stores incoming vehicle inference payloads and predictions."""
    __tablename__ = "inference_logs"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    car_name = Column(String(100), default="unknown")
    features_json = Column(Text, nullable=False)
    predicted_price = Column(Float, nullable=False)
    latency_ms = Column(Float, default=0.0)
    model_version = Column(String(50), default="1.0.0")
    
    # Optional feedback data
    actual_price = Column(Float, nullable=True)
    absolute_error = Column(Float, nullable=True)
    error_percentage = Column(Float, nullable=True)


class DriftLog(Base):
    """Stores statistical drift audits and trigger events."""
    __tablename__ = "drift_logs"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    drift_status = Column(String(50), nullable=False)  # "DRIFT_DETECTED" or "HEALTHY"
    ks_test_drifted_features = Column(Text, default="[]")
    psi_drifted_features = Column(Text, default="[]")
    sample_size = Column(Integer, default=0)
    retrain_triggered = Column(Boolean, default=False)
    notes = Column(Text, default="")


def init_db():
    """Create tables if they do not exist."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    Base.metadata.create_all(bind=engine)
    logger.info(f"Database initialized at: {DATABASE_URL}")


def get_db():
    """Dependency for acquiring database session in FastAPI."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def record_inference_log(
    car_features: Dict[str, Any],
    predicted_price: float,
    latency_ms: float = 0.0,
    model_version: str = "1.0.0"
) -> int:
    """Record an individual vehicle valuation request."""
    db = SessionLocal()
    try:
        car_name = str(car_features.get("CarName", car_features.get("car_name", "unknown")))
        log_entry = InferenceLog(
            car_name=car_name,
            features_json=json.dumps(car_features),
            predicted_price=float(predicted_price),
            latency_ms=float(latency_ms),
            model_version=model_version
        )
        db.add(log_entry)
        db.commit()
        db.refresh(log_entry)
        return log_entry.id
    except Exception as e:
        logger.error(f"Failed to record inference log: {e}")
        db.rollback()
        return -1
    finally:
        db.close()


def update_ground_truth_feedback(log_id: int, actual_price: float) -> bool:
    """Update an inference log with real-world actual sales price for accuracy monitoring."""
    db = SessionLocal()
    try:
        entry = db.query(InferenceLog).filter(InferenceLog.id == log_id).first()
        if not entry:
            return False
        
        entry.actual_price = float(actual_price)
        abs_err = abs(actual_price - entry.predicted_price)
        entry.absolute_error = abs_err
        entry.error_percentage = (abs_err / actual_price * 100) if actual_price > 0 else 0.0
        db.commit()
        return True
    except Exception as e:
        logger.error(f"Failed to update feedback for ID {log_id}: {e}")
        db.rollback()
        return False
    finally:
        db.close()


def fetch_recent_logs(limit: int = 50) -> List[Dict[str, Any]]:
    """Retrieve recent inference logs for drift analysis and reporting."""
    db = SessionLocal()
    try:
        entries = db.query(InferenceLog).order_by(desc(InferenceLog.timestamp)).limit(limit).all()
        results = []
        for e in entries:
            features = {}
            try:
                features = json.loads(e.features_json)
            except:
                pass
            results.append({
                "id": e.id,
                "timestamp": e.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "car_name": e.car_name,
                "predicted_price": e.predicted_price,
                "latency_ms": e.latency_ms,
                "model_version": e.model_version,
                "actual_price": e.actual_price,
                "error_percentage": e.error_percentage,
                "features": features
            })
        return results
    finally:
        db.close()


def record_drift_event(
    drift_status: str,
    ks_features: List[str],
    psi_features: List[str],
    sample_size: int,
    retrain_triggered: bool,
    notes: str = ""
):
    """Log drift detection results to the database."""
    db = SessionLocal()
    try:
        drift_entry = DriftLog(
            drift_status=drift_status,
            ks_test_drifted_features=json.dumps(ks_features),
            psi_drifted_features=json.dumps(psi_features),
            sample_size=sample_size,
            retrain_triggered=retrain_triggered,
            notes=notes
        )
        db.add(drift_entry)
        db.commit()
    finally:
        db.close()


# Auto-initialize tables upon module import
init_db()
