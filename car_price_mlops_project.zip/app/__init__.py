"""
FastAPI Application Package for Car Price Prediction.
"""
