"""
FastAPI Production Application for Car Price Prediction Service.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import json
import logging
from typing import Dict, Any
from fastapi import FastAPI, HTTPException, status
from fastapi.responses import JSONResponse

from src.config import (
    MODEL_SAVE_PATH,
    METRICS_SAVE_PATH,
    EDA_SUMMARY_PATH,
    DATA_VALIDATION_REPORT_PATH
)
from src.predict import CarPricePredictor
from app.schemas import (
    CarFeatures,
    PredictionResponse,
    BatchCarFeatures,
    BatchPredictionResponse,
    ModelInfoResponse
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

from contextlib import asynccontextmanager

# Global Predictor instance
predictor: CarPricePredictor = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global predictor
    try:
        if MODEL_SAVE_PATH.exists():
            predictor = CarPricePredictor(MODEL_SAVE_PATH)
            logger.info("Production predictor loaded successfully at startup.")
        else:
            logger.warning(f"Model file not found at {MODEL_SAVE_PATH}. Run training first.")
    except Exception as e:
        logger.error(f"Error loading model during startup: {e}")
    yield


app = FastAPI(
    title="MLOps Car Price Prediction API",
    description="Production-grade REST API service for automobile price estimation using trained machine learning pipelines.",
    version="1.0.0",
    lifespan=lifespan
)


@app.get("/", tags=["General"])
def root():
    return {
        "message": "Welcome to MLOps Car Price Prediction API",
        "docs_url": "/docs",
        "health_check": "/health",
        "model_info": "/model_info",
        "version": "1.0.0"
    }


@app.get("/health", tags=["Health"])
def health_check():
    model_loaded = predictor is not None and predictor.model is not None
    return {
        "status": "healthy" if model_loaded else "degraded",
        "model_loaded": model_loaded,
        "service": "car-price-prediction-api"
    }


@app.get("/model_info", response_model=ModelInfoResponse, tags=["Model Info"])
def get_model_info():
    if not METRICS_SAVE_PATH.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Model metrics not found. Please train the model first."
        )
    
    with open(METRICS_SAVE_PATH, "r") as f:
        metrics = json.load(f)
        
    test_metrics = metrics.get("best_model_test_metrics", {})
    
    return ModelInfoResponse(
        project_name="Car Price Prediction MLOps",
        version="1.0.0",
        model_name=metrics.get("best_model_name", "Unknown"),
        target_metric="R2 Score",
        r2_score=test_metrics.get("r2_score", 0.0),
        mae=test_metrics.get("mae", 0.0),
        rmse=test_metrics.get("rmse", 0.0),
        status="ready"
    )


@app.get("/metrics", tags=["Model Info"])
def get_all_metrics():
    if not METRICS_SAVE_PATH.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Model comparison metrics not found. Train models first."
        )
    with open(METRICS_SAVE_PATH, "r") as f:
        return json.load(f)


@app.get("/validation_report", tags=["Data Layer"])
def get_data_validation_report():
    if not DATA_VALIDATION_REPORT_PATH.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Data validation report not found. Run ingestion first."
        )
    with open(DATA_VALIDATION_REPORT_PATH, "r") as f:
        return json.load(f)


from app.db import (
    record_inference_log,
    update_ground_truth_feedback,
    fetch_recent_logs
)
from src.drift_detector import run_drift_audit
from src.retrain import run_automated_retraining
from src.agents.orchestrator import MLOpsMultiAgentOrchestrator
from app.schemas import (
    CarFeatures,
    PredictionResponse,
    BatchCarFeatures,
    BatchPredictionResponse,
    ModelInfoResponse,
    FeedbackRequest,
    DriftResponse,
    MultiAgentValuationRequest,
    MultiAgentValuationResponse
)

multi_agent_orchestrator = MLOpsMultiAgentOrchestrator()


@app.post("/predict", response_model=PredictionResponse, tags=["Inference"])
def predict_single_car(car: CarFeatures):
    global predictor
    if predictor is None or predictor.model is None:
        try:
            predictor = CarPricePredictor(MODEL_SAVE_PATH)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Predictor is not ready. Error: {str(e)}"
            )
            
    try:
        import time
        start_t = time.time()
        car_dict = car.model_dump()
        results = predictor.predict_formatted(car_dict)
        latency = (time.time() - start_t) * 1000

        pred_res = results[0]
        # Log to Database for monitoring & drift detection
        log_id = record_inference_log(
            car_features=car_dict,
            predicted_price=pred_res["predicted_price"],
            latency_ms=latency
        )
        return PredictionResponse(**pred_res)
    except Exception as e:
        logger.error(f"Inference error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Inference error: {str(e)}"
        )


@app.post("/batch_predict", response_model=BatchPredictionResponse, tags=["Inference"])
def predict_batch_cars(batch: BatchCarFeatures):
    global predictor
    if predictor is None or predictor.model is None:
        try:
            predictor = CarPricePredictor(MODEL_SAVE_PATH)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Predictor is not ready: {str(e)}"
            )
            
    try:
        cars_list = [c.model_dump() for c in batch.cars]
        results = predictor.predict_formatted(cars_list)
        # Log batch requests to DB
        for car_d, res in zip(cars_list, results):
            record_inference_log(car_features=car_d, predicted_price=res["predicted_price"])
            
        return BatchPredictionResponse(
            total_count=len(results),
            predictions=[PredictionResponse(**r) for r in results]
        )
    except Exception as e:
        logger.error(f"Batch inference error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Batch inference error: {str(e)}"
        )


@app.get("/logs", tags=["Monitoring & Database"])
def get_inference_logs(limit: int = 50):
    """Retrieve recent live inference requests logged to SQLite/PostgreSQL."""
    return fetch_recent_logs(limit=limit)


@app.get("/db_info", tags=["Monitoring & Database"])
def get_db_status():
    """Retrieve database connection type (PostgreSQL / SQLite) and pooling status."""
    from app.db import get_database_info
    return get_database_info()


@app.post("/feedback", tags=["Monitoring & Database"])
def submit_actual_price_feedback(feedback: FeedbackRequest):
    """Submit ground-truth actual sale price for error monitoring & drift tracking."""
    success = update_ground_truth_feedback(log_id=feedback.log_id, actual_price=feedback.actual_price)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Log entry with ID {feedback.log_id} not found."
        )
    return {"status": "success", "message": f"Feedback updated for log ID {feedback.log_id}"}


@app.get("/drift_status", tags=["Drift & Retraining"])
def check_drift_status():
    """Run real-time statistical KS-test and PSI data drift detection against baseline."""
    return run_drift_audit()


@app.post("/retrain", tags=["Drift & Retraining"])
def trigger_retraining(force: bool = False):
    """Trigger automated model retraining and champion-challenger promotion."""
    return run_automated_retraining(force=force)


@app.post("/multi_agent_val", response_model=MultiAgentValuationResponse, tags=["Multi-Agent AI"])
def evaluate_car_with_multi_agents(req: MultiAgentValuationRequest):
    """Execute Multi-Agent AI system (Data Quality, Governance, DriftOps, Pricing Intelligence)."""
    global predictor
    if predictor is None or predictor.model is None:
        predictor = CarPricePredictor(MODEL_SAVE_PATH)
    
    car_dict = req.car.model_dump()
    res = predictor.predict_formatted(car_dict)[0]
    multi_agent_report = multi_agent_orchestrator.process_vehicle_valuation(
        car_features=car_dict,
        predicted_price=res["predicted_price"]
    )
    return MultiAgentValuationResponse(**multi_agent_report)
