import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from typing import Dict, Any
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    r2_score,
    mean_absolute_error,
    mean_squared_error,
    mean_absolute_percentage_error
)

from src.config import PLOTS_DIR


def calculate_metrics(y_true: np.ndarray, y_pred: np.ndarray, n_features: int = 0) -> Dict[str, float]:
    """
    Compute comprehensive regression metrics.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    
    n_samples = len(y_true)
    r2 = float(r2_score(y_true, y_pred))
    
    # Adjusted R2
    if n_samples > n_features + 1 and n_features > 0:
        adj_r2 = float(1 - ((1 - r2) * (n_samples - 1) / (n_samples - n_features - 1)))
    else:
        adj_r2 = r2
        
    mae = float(mean_absolute_error(y_true, y_pred))
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    mape = float(mean_absolute_percentage_error(y_true, y_pred) * 100)  # in %
    
    return {
        "r2_score": round(r2, 4),
        "adjusted_r2": round(adj_r2, 4),
        "mae": round(mae, 2),
        "rmse": round(rmse, 2),
        "mape_percent": round(mape, 2)
    }


def plot_residuals_and_predictions(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model_name: str = "Best Model"
) -> None:
    """
    Generate and save Actual vs Predicted and Residual diagnostic plots.
    """
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")
    
    residuals = y_true - y_pred
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    # 1. Actual vs Predicted
    axes[0].scatter(y_true, y_pred, alpha=0.7, color="#1f77b4", edgecolors="k", s=50)
    min_val = min(y_true.min(), y_pred.min())
    max_val = max(y_true.max(), y_pred.max())
    axes[0].plot([min_val, max_val], [min_val, max_val], "r--", lw=2, label="Ideal (y = x)")
    axes[0].set_title(f"Actual vs Predicted ({model_name})", fontsize=12, weight="bold")
    axes[0].set_xlabel("Actual Price ($)", fontsize=11)
    axes[0].set_ylabel("Predicted Price ($)", fontsize=11)
    axes[0].legend()
    
    # 2. Residuals vs Predicted
    axes[1].scatter(y_pred, residuals, alpha=0.7, color="#ff7f0e", edgecolors="k", s=50)
    axes[1].axhline(0, color="r", linestyle="--", lw=2)
    axes[1].set_title("Residuals vs Predicted Values", fontsize=12, weight="bold")
    axes[1].set_xlabel("Predicted Price ($)", fontsize=11)
    axes[1].set_ylabel("Residual ($) [Actual - Pred]", fontsize=11)
    
    # 3. Residual Distribution
    sns.histplot(residuals, kde=True, ax=axes[2], color="#2ca02c", bins=15)
    axes[2].axvline(0, color="r", linestyle="--", lw=2)
    axes[2].set_title("Residuals Distribution", fontsize=12, weight="bold")
    axes[2].set_xlabel("Residual Error ($)", fontsize=11)
    axes[2].set_ylabel("Density", fontsize=11)
    
    plt.tight_layout()
    plot_path = PLOTS_DIR / "eval_residuals_and_predictions.png"
    plt.savefig(plot_path, dpi=300)
    plt.close()


def plot_model_comparison(results_df: pd.DataFrame) -> None:
    """
    Generate bar charts comparing all evaluated models on R2, MAE, and RMSE.
    """
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")
    
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    # Sort for consistent display
    sorted_df = results_df.sort_values(by="test_r2", ascending=False)
    
    # R2 Comparison
    sns.barplot(data=sorted_df, x="test_r2", y="model_name", hue="model_name", ax=axes[0], palette="Blues_r", legend=False)
    axes[0].set_title("Test R² Score Comparison (Higher is Better)", fontsize=12, weight="bold")
    axes[0].set_xlabel("R² Score", fontsize=11)
    axes[0].set_ylabel("Model", fontsize=11)
    for i, v in enumerate(sorted_df["test_r2"]):
        axes[0].text(max(0, v) + 0.01, i, f"{v:.3f}", va="center", fontsize=9, weight="bold")
        
    # MAE Comparison
    sorted_mae = results_df.sort_values(by="test_mae", ascending=True)
    sns.barplot(data=sorted_mae, x="test_mae", y="model_name", hue="model_name", ax=axes[1], palette="Greens_r", legend=False)
    axes[1].set_title("Test MAE ($) Comparison (Lower is Better)", fontsize=12, weight="bold")
    axes[1].set_xlabel("Mean Absolute Error ($)", fontsize=11)
    axes[1].set_ylabel("")
    for i, v in enumerate(sorted_mae["test_mae"]):
        axes[1].text(v + 50, i, f"${v:,.0f}", va="center", fontsize=9, weight="bold")
        
    # RMSE Comparison
    sorted_rmse = results_df.sort_values(by="test_rmse", ascending=True)
    sns.barplot(data=sorted_rmse, x="test_rmse", y="model_name", hue="model_name", ax=axes[2], palette="Oranges_r", legend=False)
    axes[2].set_title("Test RMSE ($) Comparison (Lower is Better)", fontsize=12, weight="bold")
    axes[2].set_xlabel("Root Mean Squared Error ($)", fontsize=11)
    axes[2].set_ylabel("")
    for i, v in enumerate(sorted_rmse["test_rmse"]):
        axes[2].text(v + 50, i, f"${v:,.0f}", va="center", fontsize=9, weight="bold")
        
    plt.tight_layout()
    plot_path = PLOTS_DIR / "eval_model_comparison.png"
    plt.savefig(plot_path, dpi=300)
    plt.close()


def plot_feature_importance(pipeline, feature_names: list, top_n: int = 15) -> None:
    """
    Extract and plot feature importances (or coefficients) from the trained pipeline.
    """
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    model = pipeline.named_steps["regressor"]
    
    importances = None
    title = "Top Feature Importances"
    
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        importances = np.abs(model.coef_)
        title = "Top Feature Absolute Coefficients"
        
    if importances is not None and len(importances) == len(feature_names):
        fi_df = pd.DataFrame({
            "feature": feature_names,
            "importance": importances
        }).sort_values(by="importance", ascending=False).head(top_n)
        
        plt.figure(figsize=(10, 6))
        sns.barplot(data=fi_df, x="importance", y="feature", hue="feature", palette="viridis", legend=False)
        plt.title(title, fontsize=13, weight="bold")
        plt.xlabel("Importance / Absolute Weight", fontsize=11)
        plt.ylabel("Feature", fontsize=11)
        plt.tight_layout()
        plot_path = PLOTS_DIR / "eval_feature_importance.png"
        plt.savefig(plot_path, dpi=300)
        plt.close()
