import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from typing import Tuple
import pandas as pd
from sklearn.model_selection import train_test_split
import logging

from src.config import (
    RAW_DATA_PATH,
    PROCESSED_DATA_DIR,
    TARGET_COLUMN,
    ID_COLUMN,
    RANDOM_STATE,
    TEST_SIZE
)
from src.ingestion import ingest_and_validate_data, DataIngestion

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def load_raw_data(data_path: str = None) -> pd.DataFrame:
    """
    Load and validate raw car price dataset using the DataIngestion engine.
    """
    path = Path(data_path) if data_path else RAW_DATA_PATH
    df = ingest_and_validate_data(str(path))
    return df


def split_and_save_data(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Perform stratified/random train-test split and persist splits to processed folder.
    """
    logger.info(f"Splitting data into train ({1 - TEST_SIZE:.0%}) and test ({TEST_SIZE:.0%})...")
    train_df, test_df = train_test_split(
        df,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE
    )
    
    PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)
    train_path = PROCESSED_DATA_DIR / "train.csv"
    test_path = PROCESSED_DATA_DIR / "test.csv"
    
    train_df.to_csv(train_path, index=False)
    test_df.to_csv(test_path, index=False)
    
    logger.info(f"Saved train set ({train_df.shape}) to {train_path}")
    logger.info(f"Saved test set ({test_df.shape}) to {test_path}")
    
    return train_df, test_df


if __name__ == "__main__":
    df = load_raw_data()
    train_df, test_df = split_and_save_data(df)
    print(f"Data loading and splitting complete. Train: {train_df.shape}, Test: {test_df.shape}")
