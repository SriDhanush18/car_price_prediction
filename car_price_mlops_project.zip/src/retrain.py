"""
Automated Model Retraining and Performance Champion-Challenger Promotion Engine.
Monitors drift triggers, trains challenger models, evaluates against the current production champion,
and executes automated model promotion in MLflow and disk artifacts.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import json
import logging
from typing import Dict, Any, Tuple
import pandas as pd
import joblib

from src.config import (
    RAW_DATA_PATH,
    MODEL_SAVE_PATH,
    METRICS_SAVE_PATH,
    TARGET_COLUMN
)
from src.drift_detector import run_drift_audit, DRIFT_REPORT_PATH
from src.train import run_training_pipeline
from src.mlflow_utils import log_experiment_run, REGISTERED_MODEL_NAME

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("RetrainingPipeline")


class AutomatedRetrainer:
    """Automated Retraining and Champion-Challenger Gatekeeper."""

    def __init__(self, force_retrain: bool = False):
        self.force_retrain = force_retrain

    def check_retrain_needed(self) -> Tuple[bool, str]:
        """Determine if retraining is required based on drift report or forced flag."""
        if self.force_retrain:
            return True, "Triggered manually via force flag."

        if not DRIFT_REPORT_PATH.exists():
            drift_report = run_drift_audit()
        else:
            with open(DRIFT_REPORT_PATH, "r") as f:
                drift_report = json.load(f)

        if drift_report.get("retraining_recommended", False):
            return True, f"Triggered by Statistical Drift: {drift_report.get('drifted_features_count')} drifted features detected."

        return False, "Data distribution healthy. No retraining needed."

    def execute_retraining(self) -> Dict[str, Any]:
        """Execute full retraining, benchmark, and champion-challenger evaluation."""
        logger.info("=" * 75)
        logger.info("STARTING AUTOMATED RETRAINING PIPELINE")
        logger.info("=" * 75)

        retrain_needed, reason = self.check_retrain_needed()
        logger.info(f"Retraining Check: {reason}")

        if not retrain_needed and not self.force_retrain:
            return {
                "retraining_status": "SKIPPED",
                "reason": reason,
                "action_taken": "Retained existing production model."
            }

        # 1. Load Current Champion Metrics if available
        current_champion_r2 = 0.90
        current_champion_mae = 1500.0
        if METRICS_SAVE_PATH.exists():
            try:
                with open(METRICS_SAVE_PATH, "r") as f:
                    m = json.load(f)
                    current_champion_r2 = m.get("best_model_test_metrics", {}).get("r2_score", 0.90)
                    current_champion_mae = m.get("best_model_test_metrics", {}).get("mae", 1500.0)
            except:
                pass

        # 2. Run Training Pipeline (Trains 10 models + CV + GridSearchCV Tuning)
        challenger_summary = run_training_pipeline()
        challenger_name = challenger_summary["best_model_name"]
        challenger_metrics = challenger_summary["best_model_test_metrics"]
        challenger_r2 = challenger_metrics["r2_score"]
        challenger_mae = challenger_metrics["mae"]

        # 3. Champion-Challenger Comparison Gate
        # Promote if Challenger R2 is >= Champion R2 - 0.01 (allowing small variance on new data)
        promoted = challenger_r2 >= (current_champion_r2 - 0.02)
        
        decision_record = {
            "retraining_status": "COMPLETED",
            "trigger_reason": reason,
            "champion_r2": round(float(current_champion_r2), 4),
            "champion_mae": round(float(current_champion_mae), 2),
            "challenger_model": challenger_name,
            "challenger_r2": round(float(challenger_r2), 4),
            "challenger_mae": round(float(challenger_mae), 2),
            "promoted_to_production": promoted,
            "action_taken": "Promoted challenger model to Production in MLflow and disk artifact." if promoted else "Retained current champion model."
        }

        # 4. Log Promotion Run to MLflow
        if promoted:
            try:
                log_experiment_run(
                    run_name=f"Automated_Retrain_{challenger_name}",
                    pipeline_obj=joblib.load(MODEL_SAVE_PATH),
                    params=challenger_summary.get("best_model_params", {}),
                    metrics=challenger_metrics,
                    register_model=True,
                    tags={"trigger": "automated_retrain", "status": "promoted"}
                )
            except Exception as e:
                logger.warning(f"Could not log retrain to MLflow: {e}")

        logger.info("=" * 75)
        logger.info(f"RETRAINING COMPLETE: {decision_record['action_taken']}")
        logger.info(f"Challenger Test R²: {challenger_r2:.4f} vs Champion R²: {current_champion_r2:.4f}")
        logger.info("=" * 75)

        return decision_record


def run_automated_retraining(force: bool = False):
    retrainer = AutomatedRetrainer(force_retrain=force)
    return retrainer.execute_retraining()


if __name__ == "__main__":
    result = run_automated_retraining(force=True)
    print("Retraining Output:\n", json.dumps(result, indent=2))
