"""
MLflow Tracking and Model Registry Utilities for Car Price Prediction.
Provides unified logging of experiments, parameters, cross-validation metrics,
diagnostic artifacts, and stage promotion in the Model Registry.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import os
import logging
from typing import Dict, Any, Optional, List
import pandas as pd
import numpy as np

try:
    import mlflow
    from mlflow.tracking import MlflowClient
except ImportError:
    mlflow = None
    MlflowClient = None

from src.config import BASE_DIR, MODEL_SAVE_PATH, PLOTS_DIR

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("MLflowManager")

MLFLOW_DB_PATH = BASE_DIR / "data" / "mlflow.db"
MLFLOW_ARTIFACTS_DIR = BASE_DIR / "mlruns"
EXPERIMENT_NAME = "Car_Price_Prediction_MLOps"
REGISTERED_MODEL_NAME = "CarPriceProductionModel"

# Allow file store and configure SQLite backend
os.environ["MLFLOW_ALLOW_FILE_STORE"] = "true"


def setup_mlflow():
    """Configure MLflow SQLite tracking URI and activate target experiment."""
    if mlflow is None:
        return ""
    MLFLOW_ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    tracking_uri = f"sqlite:///{str(MLFLOW_DB_PATH).replace(os.sep, '/')}"
    mlflow.set_tracking_uri(tracking_uri)
    try:
        mlflow.set_experiment(EXPERIMENT_NAME)
    except Exception as e:
        logger.warning(f"Could not activate MLflow experiment: {e}")
    return tracking_uri


def log_experiment_run(
    run_name: str,
    pipeline_obj: Any,
    params: Dict[str, Any],
    metrics: Dict[str, float],
    artifact_paths: Optional[List[Path]] = None,
    register_model: bool = False,
    tags: Optional[Dict[str, str]] = None
) -> str:
    """
    Log an individual candidate model run or tuned champion run to MLflow.
    """
    if mlflow is None:
        logger.warning("MLflow package not available. Skipping MLflow run logging.")
        return "mlflow_disabled"

    setup_mlflow()
    
    with mlflow.start_run(run_name=run_name) as run:
        run_id = run.info.run_id
        logger.info(f"Started MLflow Run '{run_name}' [ID: {run_id}]")
        
        # 1. Log Tags
        if tags:
            mlflow.set_tags(tags)
        mlflow.set_tag("project", "CarPricePrediction_MLOps")
        mlflow.set_tag("framework", "scikit-learn")
        
        # 2. Log Parameters
        if params:
            mlflow.log_params(params)
            
        # 3. Log Metrics
        if metrics:
            clean_metrics = {k: float(v) for k, v in metrics.items() if isinstance(v, (int, float, np.floating, np.integer))}
            mlflow.log_metrics(clean_metrics)
            
        # 4. Log Artifacts (Plots, Reports)
        if artifact_paths:
            for p in artifact_paths:
                if p.exists():
                    mlflow.log_artifact(str(p), artifact_path="plots_and_metrics")
                    
        # 5. Log & Register Model
        if pipeline_obj is not None and mlflow is not None:
            try:
                if register_model:
                    mlflow.sklearn.log_model(
                        sk_model=pipeline_obj,
                        artifact_path="model",
                        registered_model_name=REGISTERED_MODEL_NAME
                    )
                    logger.info(f"Logged and registered model to Registry: '{REGISTERED_MODEL_NAME}'")
                else:
                    mlflow.sklearn.log_model(
                        sk_model=pipeline_obj,
                        artifact_path="model"
                    )
            except Exception as e:
                # Fallback to direct joblib artifact logging
                if MODEL_SAVE_PATH.exists():
                    mlflow.log_artifact(str(MODEL_SAVE_PATH), artifact_path="model_artifact")
                logger.info(f"Saved model artifact to MLflow: {e}")
                
        logger.info(f"Completed MLflow Run '{run_name}' successfully.")
        return run_id


def get_latest_registered_model(model_name: str = REGISTERED_MODEL_NAME):
    """Retrieve details of the latest registered model version from MLflow Registry."""
    setup_mlflow()
    client = MlflowClient()
    try:
        models = client.search_model_versions(f"name='{model_name}'")
        if not models:
            return None
        # Return newest version
        latest = sorted(models, key=lambda m: int(m.version), reverse=True)[0]
        return {
            "name": latest.name,
            "version": latest.version,
            "current_stage": latest.current_stage,
            "source": latest.source,
            "run_id": latest.run_id,
            "status": latest.status
        }
    except Exception as e:
        logger.warning(f"Could not retrieve registered model '{model_name}': {e}")
        return None


def list_mlflow_runs(limit: int = 15) -> List[Dict[str, Any]]:
    """Query recent MLflow experiment runs for dashboard reporting."""
    if mlflow is None:
        return []
    try:
        setup_mlflow()
        client = MlflowClient()
        experiment = client.get_experiment_by_name(EXPERIMENT_NAME)
        if not experiment:
            return []
            
        runs = client.search_runs(
            experiment_ids=[experiment.experiment_id],
            order_by=["attributes.start_time DESC"],
            max_results=limit
        )
        
        run_records = []
        for r in runs:
            run_records.append({
                "run_id": r.info.run_id,
                "run_name": r.data.tags.get("mlflow.runName", "Unnamed"),
                "status": r.info.status,
                "start_time": pd.to_datetime(r.info.start_time, unit="ms").strftime("%Y-%m-%d %H:%M:%S"),
                "r2_score": r.data.metrics.get("test_r2", r.data.metrics.get("r2_score", np.nan)),
                "mae": r.data.metrics.get("test_mae", r.data.metrics.get("mae", np.nan)),
                "rmse": r.data.metrics.get("test_rmse", r.data.metrics.get("rmse", np.nan)),
                "mape_percent": r.data.metrics.get("test_mape_pct", r.data.metrics.get("mape_percent", np.nan))
            })
        return run_records
    except Exception as e:
        logger.warning(f"Could not list MLflow runs: {e}")
        return []


if __name__ == "__main__":
    setup_mlflow()
    print("MLflow initialized.")
