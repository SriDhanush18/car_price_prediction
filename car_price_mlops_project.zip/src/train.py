import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import json
import logging
from typing import Dict, Any, Tuple
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import (
    RandomForestRegressor,
    GradientBoostingRegressor,
    HistGradientBoostingRegressor
)
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import KFold, cross_val_score, GridSearchCV
from sklearn.pipeline import Pipeline

from src.config import (
    RANDOM_STATE,
    CV_FOLDS,
    PARAM_GRIDS,
    MODEL_SAVE_PATH,
    METRICS_SAVE_PATH,
    TARGET_COLUMN,
    PLOTS_DIR
)
from src.data_loader import load_raw_data, split_and_save_data
from src.preprocessor import build_preprocessor_pipeline
from src.evaluate import (
    calculate_metrics,
    plot_residuals_and_predictions,
    plot_model_comparison,
    plot_feature_importance
)
from src.mlflow_utils import log_experiment_run

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def get_candidate_models() -> Dict[str, Any]:
    """
    Instantiate diverse regression algorithms.
    """
    return {
        "Linear Regression": LinearRegression(),
        "Ridge Regression": Ridge(alpha=1.0, random_state=RANDOM_STATE),
        "Lasso Regression": Lasso(alpha=10.0, max_iter=5000, random_state=RANDOM_STATE),
        "ElasticNet": ElasticNet(alpha=1.0, l1_ratio=0.5, max_iter=5000, random_state=RANDOM_STATE),
        "Decision Tree": DecisionTreeRegressor(max_depth=6, random_state=RANDOM_STATE),
        "Random Forest": RandomForestRegressor(n_estimators=100, max_depth=10, random_state=RANDOM_STATE),
        "Gradient Boosting": GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=RANDOM_STATE),
        "HistGradientBoosting": HistGradientBoostingRegressor(max_iter=100, random_state=RANDOM_STATE),
        "Support Vector Regressor (SVR)": SVR(C=1000.0, epsilon=0.1),
        "K-Nearest Neighbors (KNN)": KNeighborsRegressor(n_neighbors=5)
    }


def train_and_evaluate_all_models(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series
) -> Tuple[pd.DataFrame, Dict[str, Pipeline]]:
    """
    Train and benchmark all candidate algorithms using 5-Fold Cross Validation.
    """
    models = get_candidate_models()
    results = []
    trained_pipelines = {}
    
    kf = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    
    logger.info("=" * 70)
    logger.info("BEGINNING MULTI-MODEL BENCHMARKING WITH 5-FOLD CROSS-VALIDATION")
    logger.info("=" * 70)
    
    for name, model in models.items():
        logger.info(f"Training and validating: {name}...")
        pipeline = Pipeline([
            ("preprocessor", build_preprocessor_pipeline()),
            ("regressor", model)
        ])
        
        # 5-Fold CV on training set
        cv_r2_scores = cross_val_score(pipeline, X_train, y_train, cv=kf, scoring="r2")
        cv_rmse_scores = np.sqrt(-cross_val_score(pipeline, X_train, y_train, cv=kf, scoring="neg_mean_squared_error"))
        
        # Fit on full training set
        pipeline.fit(X_train, y_train)
        trained_pipelines[name] = pipeline
        
        # Predictions
        train_preds = pipeline.predict(X_train)
        test_preds = pipeline.predict(X_test)
        
        # Metrics
        train_metrics = calculate_metrics(y_train, train_preds, n_features=X_train.shape[1])
        test_metrics = calculate_metrics(y_test, test_preds, n_features=X_test.shape[1])
        
        # Record results
        record = {
            "model_name": name,
            "cv_r2_mean": round(float(np.mean(cv_r2_scores)), 4),
            "cv_r2_std": round(float(np.std(cv_r2_scores)), 4),
            "cv_rmse_mean": round(float(np.mean(cv_rmse_scores)), 2),
            "train_r2": train_metrics["r2_score"],
            "test_r2": test_metrics["r2_score"],
            "test_adj_r2": test_metrics["adjusted_r2"],
            "test_mae": test_metrics["mae"],
            "test_rmse": test_metrics["rmse"],
            "test_mape_pct": test_metrics["mape_percent"]
        }
        results.append(record)

        # Log individual candidate run to MLflow
        try:
            log_experiment_run(
                run_name=f"Benchmark_{name.replace(' ', '_')}",
                pipeline_obj=pipeline,
                params={"model_type": name, "cv_folds": CV_FOLDS, "random_state": RANDOM_STATE},
                metrics={
                    "cv_r2_mean": record["cv_r2_mean"],
                    "cv_rmse_mean": record["cv_rmse_mean"],
                    "train_r2": record["train_r2"],
                    "test_r2": record["test_r2"],
                    "test_mae": record["test_mae"],
                    "test_rmse": record["test_rmse"],
                    "test_mape_pct": record["test_mape_pct"]
                },
                register_model=False,
                tags={"benchmark_candidate": "true", "algorithm": name}
            )
        except Exception as e:
            logger.warning(f"Could not log benchmark run for {name} to MLflow: {e}")
        
    results_df = pd.DataFrame(results).sort_values(by="test_r2", ascending=False).reset_index(drop=True)
    return results_df, trained_pipelines


def tune_hyperparameters(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    top_model_name: str,
    base_model: Any
) -> Pipeline:
    """
    Perform GridSearchCV hyperparameter optimization on top candidate model.
    """
    key_map = {
        "Ridge Regression": "Ridge",
        "Lasso Regression": "Lasso",
        "ElasticNet": "ElasticNet",
        "Random Forest": "RandomForest",
        "Gradient Boosting": "GradientBoosting",
        "Support Vector Regressor (SVR)": "SVR"
    }
    
    grid_key = key_map.get(top_model_name)
    pipeline = Pipeline([
        ("preprocessor", build_preprocessor_pipeline()),
        ("regressor", base_model)
    ])
    
    if grid_key and grid_key in PARAM_GRIDS:
        logger.info(f"Conducting GridSearchCV optimization for {top_model_name}...")
        kf = KFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
        grid_search = GridSearchCV(
            pipeline,
            param_grid=PARAM_GRIDS[grid_key],
            cv=kf,
            scoring="r2",
            n_jobs=1,
            refit=True
        )
        grid_search.fit(X_train, y_train)
        logger.info(f"Optimal Parameters for {top_model_name}: {grid_search.best_params_}")
        logger.info(f"Best CV R2: {grid_search.best_score_:.4f}")
        return grid_search.best_estimator_
    else:
        logger.info(f"No grid search configuration for {top_model_name}, fitting default.")
        pipeline.fit(X_train, y_train)
        return pipeline


def run_training_pipeline() -> Dict[str, Any]:
    """
    End-to-end training, benchmarking, tuning, and artifact serialization.
    """
    # 1. Load Data
    raw_df = load_raw_data()
    train_df, test_df = split_and_save_data(raw_df)
    
    X_train = train_df.drop(columns=[TARGET_COLUMN])
    y_train = train_df[TARGET_COLUMN]
    X_test = test_df.drop(columns=[TARGET_COLUMN])
    y_test = test_df[TARGET_COLUMN]
    
    # 2. Benchmark All Models
    results_df, trained_pipelines = train_and_evaluate_all_models(X_train, y_train, X_test, y_test)
    
    logger.info("\n" + results_df.to_string(index=False))
    
    # 3. Identify Top Baseline Candidate
    best_candidate_name = results_df.iloc[0]["model_name"]
    best_candidate_model = trained_pipelines[best_candidate_name].named_steps["regressor"]
    logger.info(f"Top candidate identified: {best_candidate_name}")
    
    # 4. Hyperparameter Tuning on Top Models
    tuned_best_pipeline = tune_hyperparameters(X_train, y_train, best_candidate_name, best_candidate_model)
    
    # Also evaluate tuned model on test set
    tuned_train_preds = tuned_best_pipeline.predict(X_train)
    tuned_test_preds = tuned_best_pipeline.predict(X_test)
    
    tuned_metrics = calculate_metrics(y_test, tuned_test_preds, n_features=X_test.shape[1])
    tuned_train_metrics = calculate_metrics(y_train, tuned_train_preds, n_features=X_train.shape[1])
    
    logger.info(f"Tuned Best Model ({best_candidate_name}) Test R2: {tuned_metrics['r2_score']}, MAE: ${tuned_metrics['mae']:.2f}, RMSE: ${tuned_metrics['rmse']:.2f}, MAPE: {tuned_metrics['mape_percent']}%")
    
    # 5. Serialize Best Pipeline
    joblib.dump(tuned_best_pipeline, MODEL_SAVE_PATH)
    logger.info(f"Serialized production model pipeline to {MODEL_SAVE_PATH}")
    
    # 6. Save Comparison Metrics JSON
    comparison_summary = {
        "best_model_name": f"Tuned {best_candidate_name}",
        "best_model_test_metrics": tuned_metrics,
        "best_model_train_metrics": tuned_train_metrics,
        "all_models_benchmark": results_df.to_dict(orient="records")
    }
    
    with open(METRICS_SAVE_PATH, "w") as f:
        json.dump(comparison_summary, f, indent=4)
    logger.info(f"Saved model comparison metrics to {METRICS_SAVE_PATH}")
    
    # 7. Generate Evaluation Visualizations
    plot_model_comparison(results_df)
    plot_residuals_and_predictions(y_test.values, tuned_test_preds, model_name=f"Tuned {best_candidate_name}")
    
    # Feature importance extraction
    try:
        preproc = tuned_best_pipeline.named_steps["preprocessor"]
        cat_encoder = preproc.named_steps["col_transformer"].named_transformers_["cat"]
        cat_features = preproc.named_steps["col_transformer"].transformers[0][2]
        cat_names = cat_encoder.get_feature_names_out(cat_features).tolist()
        num_features = preproc.named_steps["col_transformer"].transformers[1][2]
        feature_names = cat_names + num_features
        plot_feature_importance(tuned_best_pipeline, feature_names)
    except Exception as e:
        logger.warning(f"Could not plot feature importance: {e}")

    # 8. Log Run & Register Champion Model to MLflow
    try:
        plot_files = [
            PLOTS_DIR / "eval_model_comparison.png",
            PLOTS_DIR / "eval_residuals_and_predictions.png",
            PLOTS_DIR / "eval_feature_importance.png"
        ]
        log_experiment_run(
            run_name=f"Production_{best_candidate_name}",
            pipeline_obj=tuned_best_pipeline,
            params={"model_type": best_candidate_name, "cv_folds": CV_FOLDS},
            metrics=tuned_metrics,
            artifact_paths=plot_files,
            register_model=True,
            tags={"stage": "Production", "algorithm": best_candidate_name}
        )
    except Exception as e:
        logger.warning(f"MLflow experiment logging skipped: {e}")

    return comparison_summary


if __name__ == "__main__":
    summary = run_training_pipeline()
    print("\nTraining workflow completed successfully.")
