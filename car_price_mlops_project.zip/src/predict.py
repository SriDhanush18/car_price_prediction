"""
Inference and Prediction Pipeline for Car Price.
Handles single and batch inference on new/unseen automotive data.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from typing import Union, List, Dict, Any
import joblib
import pandas as pd
import numpy as np
import logging

from src.config import MODEL_SAVE_PATH

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


class CarPricePredictor:
    """
    Production inference engine that wraps the trained Pipeline artifact.
    """
    def __init__(self, model_path: Union[str, Path] = None):
        self.model_path = Path(model_path) if model_path else MODEL_SAVE_PATH
        self.model = None
        self._load_model()

    def _load_model(self):
        if not self.model_path.exists():
            raise FileNotFoundError(f"Trained model not found at {self.model_path}. Run training first.")
        logger.info(f"Loading production pipeline from {self.model_path}...")
        self.model = joblib.load(self.model_path)

    def predict(self, input_data: Union[Dict[str, Any], List[Dict[str, Any]], pd.DataFrame]) -> np.ndarray:
        """
        Run inference on single dictionary, list of dictionaries, or pandas DataFrame.
        """
        if isinstance(input_data, dict):
            df = pd.DataFrame([input_data])
        elif isinstance(input_data, list):
            df = pd.DataFrame(input_data)
        elif isinstance(input_data, pd.DataFrame):
            df = input_data.copy()
        else:
            raise ValueError(f"Unsupported input type: {type(input_data)}")

        predictions = self.model.predict(df)
        return np.round(predictions, 2)

    def predict_formatted(self, input_data: Union[Dict[str, Any], List[Dict[str, Any]], pd.DataFrame]) -> List[Dict[str, Any]]:
        """
        Run inference and return formatted output with input identifiers.
        """
        if isinstance(input_data, dict):
            input_records = [input_data]
            df = pd.DataFrame([input_data])
        elif isinstance(input_data, list):
            input_records = input_data
            df = pd.DataFrame(input_data)
        elif isinstance(input_data, pd.DataFrame):
            input_records = input_data.to_dict(orient="records")
            df = input_data.copy()
        else:
            raise ValueError(f"Unsupported input type: {type(input_data)}")

        preds = self.predict(df)
        
        results = []
        for i, pred in enumerate(preds):
            rec = input_records[i]
            car_name = rec.get("CarName", rec.get("brand", f"Car #{i+1}"))
            results.append({
                "car_identifier": car_name,
                "predicted_price": float(pred),
                "predicted_price_formatted": f"${pred:,.2f}"
            })
        return results


if __name__ == "__main__":
    predictor = CarPricePredictor()
    
    # Sample unseen test vehicles
    sample_cars = [
        {
            "CarName": "toyota camry se",
            "fueltype": "gas",
            "aspiration": "std",
            "doornumber": "four",
            "carbody": "sedan",
            "drivewheel": "fwd",
            "enginelocation": "front",
            "wheelbase": 102.4,
            "carlength": 175.6,
            "carwidth": 66.5,
            "carheight": 54.9,
            "curbweight": 2400,
            "enginetype": "ohc",
            "cylindernumber": "four",
            "enginesize": 122,
            "fuelsystem": "mpfi",
            "boreratio": 3.31,
            "stroke": 3.54,
            "compressionratio": 8.7,
            "horsepower": 95,
            "peakrpm": 4500,
            "citympg": 28,
            "highwaympg": 34,
            "symboling": 0
        },
        {
            "CarName": "bmw m3 competition",
            "fueltype": "gas",
            "aspiration": "turbo",
            "doornumber": "two",
            "carbody": "sedan",
            "drivewheel": "rwd",
            "enginelocation": "front",
            "wheelbase": 108.5,
            "carlength": 190.0,
            "carwidth": 71.0,
            "carheight": 54.0,
            "curbweight": 3600,
            "enginetype": "ohc",
            "cylindernumber": "six",
            "enginesize": 215,
            "fuelsystem": "mpfi",
            "boreratio": 3.65,
            "stroke": 3.40,
            "compressionratio": 9.5,
            "horsepower": 260,
            "peakrpm": 6000,
            "citympg": 16,
            "highwaympg": 22,
            "symboling": 3
        }
    ]
    
    predictions = predictor.predict_formatted(sample_cars)
    print("\nSample Predictions:")
    for p in predictions:
        print(f"Vehicle: {p['car_identifier']} -> Predicted Price: {p['predicted_price_formatted']}")
