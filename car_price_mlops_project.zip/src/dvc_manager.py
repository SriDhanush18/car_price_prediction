"""
Data Version Control (DVC) Manager for Car Price Prediction.
Automates dataset versioning, md5 hash tracking, remote cache synchronization,
and reproducible pipeline DAG execution.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import os
import subprocess
import json
import logging
import hashlib
from typing import Dict, Any, List, Optional

from src.config import BASE_DIR, DATA_DIR, RAW_DATA_PATH

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("DVCManager")

DVC_DIR = BASE_DIR / ".dvc"
DVC_STORAGE_DIR = BASE_DIR / "dvc_remote_storage"


def compute_file_md5(file_path: Path) -> str:
    """Compute standard MD5 hash for a dataset file."""
    if not file_path.exists():
        return ""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def init_dvc_environment() -> Dict[str, Any]:
    """Initialize DVC repository and local remote storage."""
    DVC_STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    
    # 1. Initialize git if not present (DVC works best with git)
    git_dir = BASE_DIR / ".git"
    if not git_dir.exists():
        try:
            subprocess.run(["git", "init"], cwd=str(BASE_DIR), capture_output=True, text=True)
            logger.info("Initialized local Git repository for DVC integration.")
        except Exception as e:
            logger.warning(f"Git init skipped: {e}")

    # 2. Initialize DVC
    dvc_initialized = DVC_DIR.exists()
    if not dvc_initialized:
        try:
            res = subprocess.run(["dvc", "init", "--no-scm"], cwd=str(BASE_DIR), capture_output=True, text=True)
            if res.returncode != 0:
                # Try standard dvc init
                res = subprocess.run(["dvc", "init"], cwd=str(BASE_DIR), capture_output=True, text=True)
            logger.info(f"DVC initialized: {res.stdout.strip() or res.stderr.strip()}")
            dvc_initialized = True
        except Exception as e:
            logger.warning(f"DVC CLI init error: {e}")

    # 3. Configure local remote storage
    try:
        remote_path = str(DVC_STORAGE_DIR).replace(os.sep, "/")
        subprocess.run(["dvc", "remote", "add", "-d", "-f", "local_storage", remote_path], cwd=str(BASE_DIR), capture_output=True, text=True)
        logger.info(f"Configured DVC default remote storage at: {remote_path}")
    except Exception as e:
        logger.warning(f"DVC remote configuration: {e}")

    return {
        "dvc_initialized": DVC_DIR.exists(),
        "remote_storage": str(DVC_STORAGE_DIR),
        "dvc_config_exists": (DVC_DIR / "config").exists() if DVC_DIR.exists() else False
    }


def track_dataset_version(file_path: Path) -> Dict[str, Any]:
    """Track a specific dataset with DVC and generate pointer file."""
    if not file_path.exists():
        raise FileNotFoundError(f"File {file_path} not found.")

    rel_path = file_path.relative_to(BASE_DIR)
    md5_hash = compute_file_md5(file_path)
    file_size_kb = file_path.stat().st_size / 1024

    # Run dvc add
    try:
        res = subprocess.run(["dvc", "add", str(rel_path)], cwd=str(BASE_DIR), capture_output=True, text=True)
        logger.info(f"DVC tracked {rel_path}: {res.stdout.strip() or res.stderr.strip()}")
    except Exception as e:
        logger.warning(f"DVC CLI add command: {e}")

    # Create explicit .dvc tracking metadata
    dvc_file = BASE_DIR / f"{rel_path}.dvc"
    tracking_info = {
        "file_name": file_path.name,
        "relative_path": str(rel_path),
        "md5_checksum": md5_hash,
        "size_kb": round(file_size_kb, 2),
        "dvc_pointer_file": str(dvc_file.relative_to(BASE_DIR)) if dvc_file.exists() else f"{rel_path}.dvc",
        "status": "TRACKED_BY_DVC"
    }

    return tracking_info


def get_all_tracked_datasets() -> List[Dict[str, Any]]:
    """Scan and list all datasets versioned by DVC."""
    target_files = [
        DATA_DIR / "raw" / "CarPrice_Assignment.csv",
        DATA_DIR / "processed" / "train.csv",
        DATA_DIR / "processed" / "test.csv"
    ]

    tracked = []
    for f in target_files:
        if f.exists():
            rel_path = f.relative_to(BASE_DIR)
            dvc_pointer = BASE_DIR / f"{rel_path}.dvc"
            md5_hash = compute_file_md5(f)
            tracked.append({
                "dataset_name": f.name,
                "path": str(rel_path),
                "md5_checksum": md5_hash,
                "size_kb": f"{f.stat().st_size / 1024:.2f} KB",
                "dvc_pointer_exists": dvc_pointer.exists(),
                "status": "Version Controlled (DVC)"
            })
    return tracked


def run_dvc_pipeline_reproduction() -> Dict[str, Any]:
    """Execute DVC pipeline reproduction across the entire DAG."""
    try:
        res = subprocess.run(["dvc", "repro"], cwd=str(BASE_DIR), capture_output=True, text=True)
        logger.info(f"DVC Repro Output:\n{res.stdout}\n{res.stderr}")
        return {
            "status": "SUCCESS" if res.returncode == 0 else "WARNING",
            "stdout": res.stdout,
            "stderr": res.stderr
        }
    except Exception as e:
        logger.warning(f"Could not run dvc repro: {e}")
        return {"status": "ERROR", "message": str(e)}


if __name__ == "__main__":
    init_info = init_dvc_environment()
    print("DVC Init:", json.dumps(init_info, indent=2))
    
    # Track raw dataset
    raw_track = track_dataset_version(RAW_DATA_PATH)
    print("Tracked Raw:", json.dumps(raw_track, indent=2))
    
    # List tracked
    all_tracked = get_all_tracked_datasets()
    print("All Tracked Datasets:\n", json.dumps(all_tracked, indent=2))
