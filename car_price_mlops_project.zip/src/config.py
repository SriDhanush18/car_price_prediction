"""
Configuration and constants for MLOps Car Price Prediction Project.
"""
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_PATH = DATA_DIR / "raw" / "CarPrice_Assignment.csv"
FALLBACK_RAW_DATA_PATH = DATA_DIR / "raw" / "car_price.csv"
PROCESSED_DATA_DIR = DATA_DIR / "processed"

ARTIFACTS_DIR = BASE_DIR / "artifacts"
MODELS_DIR = ARTIFACTS_DIR / "models"
METRICS_DIR = ARTIFACTS_DIR / "metrics"
PLOTS_DIR = ARTIFACTS_DIR / "plots"

# Ensure directories exist
for p in [PROCESSED_DATA_DIR, MODELS_DIR, METRICS_DIR, PLOTS_DIR]:
    p.mkdir(parents=True, exist_ok=True)

MODEL_SAVE_PATH = MODELS_DIR / "best_model.joblib"
METRICS_SAVE_PATH = METRICS_DIR / "model_comparison.json"
EDA_SUMMARY_PATH = METRICS_DIR / "eda_summary.json"
DATA_VALIDATION_REPORT_PATH = METRICS_DIR / "data_validation_report.json"

# Columns Definition
TARGET_COLUMN = "price"
ID_COLUMN = "car_ID"
CAR_NAME_COLUMN = "CarName"

EXPECTED_RAW_COLUMNS = [
    "car_ID", "symboling", "CarName", "fueltype", "aspiration",
    "doornumber", "carbody", "drivewheel", "enginelocation", "wheelbase",
    "carlength", "carwidth", "carheight", "curbweight", "enginetype",
    "cylindernumber", "enginesize", "fuelsystem", "boreratio", "stroke",
    "compressionratio", "horsepower", "peakrpm", "citympg", "highwaympg", "price"
]

# Validation Value Constraints
NUMERICAL_VALIDATION_RANGES = {
    "wheelbase": (70.0, 150.0),
    "carlength": (100.0, 250.0),
    "carwidth": (50.0, 90.0),
    "carheight": (40.0, 75.0),
    "curbweight": (1000.0, 6000.0),
    "enginesize": (40.0, 500.0),
    "horsepower": (30.0, 600.0),
    "citympg": (5.0, 80.0),
    "highwaympg": (5.0, 80.0),
    "price": (1000.0, 200000.0)
}

VALID_CATEGORICAL_VALUES = {
    "fueltype": {"gas", "diesel"},
    "aspiration": {"std", "turbo"},
    "doornumber": {"two", "four"},
    "carbody": {"convertible", "hatchback", "sedan", "wagon", "hardtop"},
    "drivewheel": {"rwd", "fwd", "4wd"},
    "enginelocation": {"front", "rear"}
}

# Feature Categorizations
NOMINAL_CATEGORICAL_COLS = [
    "brand",
    "fueltype",
    "aspiration",
    "carbody",
    "drivewheel",
    "enginelocation",
    "enginetype",
    "fuelsystem"
]

ORDINAL_WORD_COLS = {
    "doornumber": {"two": 2, "four": 4},
    "cylindernumber": {
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "eight": 8,
        "twelve": 12
    }
}

NUMERICAL_COLS = [
    "symboling",
    "doornumber_num",
    "cylindernumber_num",
    "wheelbase",
    "carlength",
    "carwidth",
    "carheight",
    "curbweight",
    "enginesize",
    "boreratio",
    "stroke",
    "compressionratio",
    "horsepower",
    "peakrpm",
    "citympg",
    "highwaympg",
    # Engineered features
    "power_to_weight",
    "car_volume",
    "avg_mpg",
    "engine_displacement_ratio",
    "is_luxury_brand"
]

# Brand Name Cleaning Map (fixing dataset typos)
BRAND_MAPPING = {
    "maxda": "mazda",
    "porcshce": "porsche",
    "toyouta": "toyota",
    "vokswagen": "volkswagen",
    "vw": "volkswagen"
}

# Luxury Brands List
LUXURY_BRANDS = {"audi", "bmw", "jaguar", "porsche", "buick", "volvo"}

# Modeling & Validation Config
RANDOM_STATE = 42
TEST_SIZE = 0.20
CV_FOLDS = 5

# Hyperparameter Grids for Tuning
PARAM_GRIDS = {
    "Ridge": {
        "regressor__alpha": [0.1, 1.0, 10.0, 50.0]
    },
    "Lasso": {
        "regressor__alpha": [1.0, 10.0, 50.0],
        "regressor__max_iter": [5000]
    },
    "ElasticNet": {
        "regressor__alpha": [0.1, 1.0],
        "regressor__l1_ratio": [0.3, 0.7],
        "regressor__max_iter": [5000]
    },
    "RandomForest": {
        "regressor__n_estimators": [100, 150],
        "regressor__max_depth": [None, 10],
        "regressor__min_samples_split": [2, 4]
    },
    "GradientBoosting": {
        "regressor__n_estimators": [100, 150],
        "regressor__learning_rate": [0.05, 0.1],
        "regressor__max_depth": [3, 4]
    },
    "SVR": {
        "regressor__C": [1000.0, 5000.0],
        "regressor__gamma": ["scale", 0.1]
    }
}
