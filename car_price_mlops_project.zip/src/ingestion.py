"""
Data Layer Ingestion and Validation Engine.
Pipeline: CarPrice_Assignment.csv -> data/raw/ -> ingestion.py -> pandas DataFrame -> Data Validation
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import json
import logging
from typing import Tuple, Dict, Any, Optional
import pandas as pd
import numpy as np

from src.config import (
    RAW_DATA_PATH,
    FALLBACK_RAW_DATA_PATH,
    EXPECTED_RAW_COLUMNS,
    NUMERICAL_VALIDATION_RANGES,
    VALID_CATEGORICAL_VALUES,
    DATA_VALIDATION_REPORT_PATH,
    TARGET_COLUMN
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("DataIngestion")


class DataIngestion:
    """
    Handles ingestion of raw automobile CSV data and performs comprehensive schema,
    null, duplicate, categorical, and range validation checks.
    """
    def __init__(self, raw_path: Optional[Path] = None):
        self.raw_path = Path(raw_path) if raw_path else RAW_DATA_PATH
        self.validation_report: Dict[str, Any] = {}

    def locate_raw_file(self) -> Path:
        """Locate raw file with fallback support."""
        if self.raw_path.exists():
            return self.raw_path
        if FALLBACK_RAW_DATA_PATH.exists():
            logger.warning(f"Primary file {self.raw_path} not found. Falling back to {FALLBACK_RAW_DATA_PATH}")
            return FALLBACK_RAW_DATA_PATH
        raise FileNotFoundError(f"Raw data file not found at {self.raw_path} or {FALLBACK_RAW_DATA_PATH}")

    def ingest_raw_data(self) -> pd.DataFrame:
        """
        Ingest CSV file from data/raw/ into a pandas DataFrame.
        """
        target_path = self.locate_raw_file()
        logger.info(f"Ingesting raw dataset from: {target_path}...")
        
        try:
            df = pd.read_csv(target_path)
            logger.info(f"Ingestion successful: {df.shape[0]} rows, {df.shape[1]} columns loaded into pandas DataFrame.")
            return df
        except Exception as e:
            logger.error(f"Failed to ingest CSV: {e}")
            raise

    def validate_data(self, df: pd.DataFrame) -> Tuple[bool, Dict[str, Any]]:
        """
        Execute full validation suite on pandas DataFrame:
        - Schema & Column Integrity
        - Null / Missing Values
        - Duplicate Rows
        - Domain Ranges (Numerical bounds)
        - Categorical Domain Integrity
        """
        logger.info("Executing enterprise Data Validation checks...")
        checks = {}
        all_passed = True

        # 1. Row count check
        min_expected_rows = 100
        has_sufficient_rows = len(df) >= min_expected_rows
        checks["row_count_check"] = {
            "passed": bool(has_sufficient_rows),
            "actual_rows": len(df),
            "min_required": min_expected_rows
        }
        if not has_sufficient_rows:
            all_passed = False

        # 2. Schema / Expected Columns
        missing_cols = [c for c in EXPECTED_RAW_COLUMNS if c not in df.columns]
        extra_cols = [c for c in df.columns if c not in EXPECTED_RAW_COLUMNS]
        schema_passed = len(missing_cols) == 0
        checks["schema_columns_check"] = {
            "passed": schema_passed,
            "missing_columns": missing_cols,
            "extra_columns": extra_cols,
            "expected_count": len(EXPECTED_RAW_COLUMNS),
            "actual_count": len(df.columns)
        }
        if not schema_passed:
            all_passed = False

        # 3. Missing / Null Values
        null_counts = df.isnull().sum().to_dict()
        total_nulls = int(df.isnull().sum().sum())
        nulls_passed = total_nulls == 0
        checks["missing_values_check"] = {
            "passed": nulls_passed,
            "total_null_count": total_nulls,
            "columns_with_nulls": {k: int(v) for k, v in null_counts.items() if v > 0}
        }
        if not nulls_passed:
            all_passed = False

        # 4. Duplicate Records Check
        duplicate_count = int(df.duplicated().sum())
        duplicates_passed = duplicate_count == 0
        checks["duplicate_records_check"] = {
            "passed": duplicates_passed,
            "duplicate_rows_count": duplicate_count
        }
        if not duplicates_passed:
            all_passed = False

        # 5. Numerical Range Validity
        range_violations = {}
        for col, (min_val, max_val) in NUMERICAL_VALIDATION_RANGES.items():
            if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
                out_of_bounds = df[(df[col] < min_val) | (df[col] > max_val)]
                if len(out_of_bounds) > 0:
                    range_violations[col] = {
                        "violation_count": len(out_of_bounds),
                        "allowed_range": [min_val, max_val],
                        "actual_min": float(df[col].min()),
                        "actual_max": float(df[col].max())
                    }
        ranges_passed = len(range_violations) == 0
        checks["numerical_ranges_check"] = {
            "passed": ranges_passed,
            "violations": range_violations
        }
        if not ranges_passed:
            all_passed = False

        # 6. Categorical Domain Integrity
        categorical_violations = {}
        for col, valid_set in VALID_CATEGORICAL_VALUES.items():
            if col in df.columns:
                actual_unique = set(df[col].astype(str).str.lower().unique())
                invalid_entries = actual_unique - valid_set
                if len(invalid_entries) > 0:
                    categorical_violations[col] = {
                        "invalid_values": list(invalid_entries),
                        "allowed_values": list(valid_set)
                    }
        cat_passed = len(categorical_violations) == 0
        checks["categorical_domains_check"] = {
            "passed": cat_passed,
            "violations": categorical_violations
        }
        if not cat_passed:
            all_passed = False

        # Compile Full Report
        report = {
            "validation_status": "PASSED" if all_passed else "FAILED",
            "dataset_shape": {"rows": len(df), "columns": len(df.columns)},
            "checks_summary": {
                "total_checks": len(checks),
                "passed_checks": sum(1 for c in checks.values() if c["passed"]),
                "failed_checks": sum(1 for c in checks.values() if not c["passed"])
            },
            "detailed_checks": checks
        }

        self.validation_report = report
        
        # Persist report
        DATA_VALIDATION_REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(DATA_VALIDATION_REPORT_PATH, "w") as f:
            json.dump(report, f, indent=4)
        logger.info(f"Data validation complete. Status: {report['validation_status']}. Report saved to {DATA_VALIDATION_REPORT_PATH}")

        return all_passed, report

    def get_validated_data(self) -> pd.DataFrame:
        """
        High-level entrypoint: Ingests raw CSV and verifies all validation constraints.
        """
        df = self.ingest_raw_data()
        is_valid, report = self.validate_data(df)
        if not is_valid:
            failed_reasons = [k for k, v in report["detailed_checks"].items() if not v["passed"]]
            raise ValueError(f"Data Validation Failed! Violations in: {failed_reasons}")
        return df


def ingest_and_validate_data(raw_path: Optional[str] = None) -> pd.DataFrame:
    """Convenience function for pipeline integration."""
    path = Path(raw_path) if raw_path else None
    ingestion = DataIngestion(path)
    return ingestion.get_validated_data()


if __name__ == "__main__":
    ingestion = DataIngestion()
    df = ingestion.get_validated_data()
    print("\nData Layer Ingestion & Validation Output:")
    print("=" * 60)
    print(f"DataFrame Loaded: {df.shape[0]} rows, {df.shape[1]} columns")
    print(f"Validation Status: {ingestion.validation_report['validation_status']}")
    print(f"Checks Passed: {ingestion.validation_report['checks_summary']['passed_checks']}/{ingestion.validation_report['checks_summary']['total_checks']}")
    print("=" * 60)
