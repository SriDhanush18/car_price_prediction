import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.config import (
    BRAND_MAPPING,
    LUXURY_BRANDS,
    ORDINAL_WORD_COLS,
    NOMINAL_CATEGORICAL_COLS,
    NUMERICAL_COLS,
    CAR_NAME_COLUMN,
    ID_COLUMN
)


class CarFeatureEngineer(BaseEstimator, TransformerMixin):
    """
    Custom transformer to parse car name, fix brand typos,
    encode worded counts into integers, and engineer domain features.
    """
    def __init__(self):
        self.brand_mapping = BRAND_MAPPING
        self.luxury_brands = LUXURY_BRANDS
        self.ordinal_word_cols = ORDINAL_WORD_COLS

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        # Convert to DataFrame if not already
        if not isinstance(X, pd.DataFrame):
            X_df = pd.DataFrame(X).copy()
        else:
            X_df = X.copy()

        # 1. Extract brand from CarName if present
        if CAR_NAME_COLUMN in X_df.columns:
            raw_brand = X_df[CAR_NAME_COLUMN].apply(
                lambda x: str(x).strip().split()[0].lower() if pd.notnull(x) and str(x).strip() else "unknown"
            )
            X_df["brand"] = raw_brand.replace(self.brand_mapping)
        elif "brand" in X_df.columns:
            X_df["brand"] = X_df["brand"].astype(str).str.strip().str.lower().replace(self.brand_mapping)
        else:
            X_df["brand"] = "unknown"

        # 2. Convert worded numbers to integers
        for col, mapping in self.ordinal_word_cols.items():
            num_col_name = f"{col}_num"
            if col in X_df.columns:
                X_df[num_col_name] = X_df[col].astype(str).str.lower().map(mapping).fillna(4).astype(float)
            else:
                # Default fallback
                X_df[num_col_name] = 4.0

        # 3. Domain Feature Engineering
        # Power-to-weight ratio
        curbweight = X_df["curbweight"].astype(float) if "curbweight" in X_df.columns else 2500.0
        horsepower = X_df["horsepower"].astype(float) if "horsepower" in X_df.columns else 100.0
        X_df["power_to_weight"] = np.where(curbweight > 0, horsepower / curbweight, 0.0)

        # Vehicle Volume (Length * Width * Height)
        length = X_df["carlength"].astype(float) if "carlength" in X_df.columns else 170.0
        width = X_df["carwidth"].astype(float) if "carwidth" in X_df.columns else 65.0
        height = X_df["carheight"].astype(float) if "carheight" in X_df.columns else 53.0
        X_df["car_volume"] = length * width * height

        # Combined Average MPG (55% city, 45% highway)
        city_mpg = X_df["citympg"].astype(float) if "citympg" in X_df.columns else 25.0
        hwy_mpg = X_df["highwaympg"].astype(float) if "highwaympg" in X_df.columns else 30.0
        X_df["avg_mpg"] = (city_mpg * 0.55) + (hwy_mpg * 0.45)

        # Engine Displacement per Cylinder
        cylinders = X_df["cylindernumber_num"].replace(0, 4.0)
        enginesize = X_df["enginesize"].astype(float) if "enginesize" in X_df.columns else 120.0
        X_df["engine_displacement_ratio"] = enginesize / cylinders

        # Luxury Brand indicator
        X_df["is_luxury_brand"] = X_df["brand"].apply(lambda b: 1.0 if b in self.luxury_brands else 0.0)

        # Ensure all expected numerical columns exist
        for col in NUMERICAL_COLS:
            if col not in X_df.columns:
                X_df[col] = 0.0
            else:
                X_df[col] = pd.to_numeric(X_df[col], errors="coerce").fillna(0.0)

        # Ensure all expected categorical columns exist
        for col in NOMINAL_CATEGORICAL_COLS:
            if col not in X_df.columns:
                X_df[col] = "unknown"
            else:
                X_df[col] = X_df[col].astype(str).str.lower().fillna("unknown")

        return X_df


def build_preprocessor_pipeline() -> Pipeline:
    """
    Constructs the complete transformation pipeline:
    Feature Engineering -> ColumnTransformer (OneHotEncoder + StandardScaler).
    """
    col_transformer = ColumnTransformer(
        transformers=[
            (
                "cat",
                OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                NOMINAL_CATEGORICAL_COLS
            ),
            (
                "num",
                StandardScaler(),
                NUMERICAL_COLS
            )
        ],
        remainder="drop"
    )

    full_pipeline = Pipeline([
        ("feature_engineer", CarFeatureEngineer()),
        ("col_transformer", col_transformer)
    ])

    return full_pipeline


if __name__ == "__main__":
    from src.data_loader import load_raw_data
    df = load_raw_data()
    pipeline = build_preprocessor_pipeline()
    X = df.drop(columns=["price"])
    X_trans = pipeline.fit_transform(X)
    print("Preprocessing successful! Transformed shape:", X_trans.shape)
