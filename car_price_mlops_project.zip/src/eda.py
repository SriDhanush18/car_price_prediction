import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import json
import logging
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns

from src.config import (
    PLOTS_DIR,
    EDA_SUMMARY_PATH,
    TARGET_COLUMN,
    BRAND_MAPPING
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


def extract_cleaned_brand(df: pd.DataFrame) -> pd.Series:
    """Extract and correct brand names from CarName."""
    raw_brand = df["CarName"].apply(lambda x: str(x).split()[0].lower())
    return raw_brand.replace(BRAND_MAPPING)


def detect_outliers_iqr(df: pd.DataFrame, num_cols: list) -> dict:
    """Detect outliers in numerical columns using IQR method."""
    outlier_counts = {}
    for col in num_cols:
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)]
            outlier_counts[col] = {
                "count": int(len(outliers)),
                "percentage": round(float(len(outliers) / len(df) * 100), 2),
                "lower_bound": round(float(lower_bound), 2),
                "upper_bound": round(float(upper_bound), 2)
            }
    return outlier_counts


def run_eda(df: pd.DataFrame) -> dict:
    """
    Run full EDA pipeline and save charts and statistical summaries.
    """
    logger.info("Executing comprehensive Exploratory Data Analysis...")
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    EDA_SUMMARY_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    # 1. Dataset Dimensions & Basic Checks
    n_rows, n_cols = df.shape
    missing_vals = int(df.isnull().sum().sum())
    duplicate_rows = int(df.duplicated().sum())
    
    # 2. Extract Clean Brand
    df_eda = df.copy()
    df_eda["brand"] = extract_cleaned_brand(df_eda)
    
    # 3. Numeric Columns & Outlier Detection
    numeric_cols = df_eda.select_dtypes(include=[np.number]).columns.tolist()
    if "car_ID" in numeric_cols:
        numeric_cols.remove("car_ID")
        
    outliers_iqr = detect_outliers_iqr(df_eda, numeric_cols)
    
    # 4. Correlation with Target
    correlations = {}
    if TARGET_COLUMN in numeric_cols:
        corr_series = df_eda[numeric_cols].corr()[TARGET_COLUMN].drop(TARGET_COLUMN).sort_values(ascending=False)
        correlations = {k: round(float(v), 4) for k, v in corr_series.items()}
    
    # 5. Price Distribution Statistics
    price_stats = {
        "mean": round(float(df[TARGET_COLUMN].mean()), 2),
        "median": round(float(df[TARGET_COLUMN].median()), 2),
        "std": round(float(df[TARGET_COLUMN].std()), 2),
        "min": round(float(df[TARGET_COLUMN].min()), 2),
        "max": round(float(df[TARGET_COLUMN].max()), 2),
        "skewness": round(float(df[TARGET_COLUMN].skew()), 3),
        "kurtosis": round(float(df[TARGET_COLUMN].kurtosis()), 3)
    }
    
    # 6. Brand summary
    brand_counts = df_eda["brand"].value_counts().to_dict()
    
    summary = {
        "dataset_shape": {"rows": n_rows, "columns": n_cols},
        "missing_values_count": missing_vals,
        "duplicate_rows_count": duplicate_rows,
        "target_variable": TARGET_COLUMN,
        "price_statistics": price_stats,
        "brand_distribution": brand_counts,
        "top_positive_correlations": {k: v for k, v in list(correlations.items())[:5]},
        "top_negative_correlations": {k: v for k, v in list(correlations.items())[-5:]},
        "outliers_by_feature": outliers_iqr
    }
    
    # Save Summary JSON
    with open(EDA_SUMMARY_PATH, "w") as f:
        json.dump(summary, f, indent=4)
    logger.info(f"Saved EDA statistical summary to {EDA_SUMMARY_PATH}")
    
    # 7. Generate Visualizations
    sns.set_theme(style="whitegrid", palette="muted")
    
    # Plot 1: Target Price Distribution
    plt.figure(figsize=(10, 5))
    sns.histplot(df_eda[TARGET_COLUMN], kde=True, color="#1f77b4", bins=25)
    plt.title("Distribution of Car Prices (Target Variable)", fontsize=14, weight="bold")
    plt.xlabel("Price ($)", fontsize=12)
    plt.ylabel("Frequency", fontsize=12)
    plt.axvline(price_stats["median"], color="red", linestyle="--", label=f"Median: ${price_stats['median']:,.0f}")
    plt.axvline(price_stats["mean"], color="green", linestyle="-.", label=f"Mean: ${price_stats['mean']:,.0f}")
    plt.legend()
    plt.tight_layout()
    plot1_path = PLOTS_DIR / "eda_price_distribution.png"
    plt.savefig(plot1_path, dpi=300)
    plt.close()
    
    # Plot 2: Correlation Heatmap
    plt.figure(figsize=(14, 10))
    corr_matrix = df_eda[numeric_cols].corr()
    sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm", cbar=True, square=True, linewidths=0.5)
    plt.title("Feature Correlation Heatmap", fontsize=15, weight="bold")
    plt.tight_layout()
    plot2_path = PLOTS_DIR / "eda_correlation_heatmap.png"
    plt.savefig(plot2_path, dpi=300)
    plt.close()
    
    # Plot 3: Price by Brand Boxplot
    plt.figure(figsize=(15, 6))
    order = df_eda.groupby("brand")[TARGET_COLUMN].median().sort_values(ascending=False).index
    sns.boxplot(data=df_eda, x="brand", y=TARGET_COLUMN, order=order, palette="tab20")
    plt.xticks(rotation=45, ha="right")
    plt.title("Car Price Distribution Across Brands (Ranked by Median Price)", fontsize=14, weight="bold")
    plt.xlabel("Brand", fontsize=12)
    plt.ylabel("Price ($)", fontsize=12)
    plt.tight_layout()
    plot3_path = PLOTS_DIR / "eda_price_by_brand.png"
    plt.savefig(plot3_path, dpi=300)
    plt.close()
    
    # Plot 4: Scatter plots of Top Engine Features vs Price
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    sns.regplot(data=df_eda, x="enginesize", y=TARGET_COLUMN, ax=axes[0], color="#2ca02c", scatter_kws={"alpha":0.6})
    axes[0].set_title("Engine Size vs Price", weight="bold")
    axes[0].set_xlabel("Engine Size (cu in)")
    axes[0].set_ylabel("Price ($)")
    
    sns.regplot(data=df_eda, x="curbweight", y=TARGET_COLUMN, ax=axes[1], color="#ff7f0e", scatter_kws={"alpha":0.6})
    axes[1].set_title("Curb Weight vs Price", weight="bold")
    axes[1].set_xlabel("Curb Weight (lbs)")
    axes[1].set_ylabel("Price ($)")
    
    sns.regplot(data=df_eda, x="horsepower", y=TARGET_COLUMN, ax=axes[2], color="#d62728", scatter_kws={"alpha":0.6})
    axes[2].set_title("Horsepower vs Price", weight="bold")
    axes[2].set_xlabel("Horsepower (hp)")
    axes[2].set_ylabel("Price ($)")
    
    plt.tight_layout()
    plot4_path = PLOTS_DIR / "eda_engine_vs_price.png"
    plt.savefig(plot4_path, dpi=300)
    plt.close()
    
    logger.info("EDA visualizations saved successfully.")
    return summary


if __name__ == "__main__":
    from src.data_loader import load_raw_data
    df = load_raw_data()
    summary = run_eda(df)
    print("EDA Complete. Summary:", json.dumps(summary, indent=2))
